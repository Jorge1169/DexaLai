<?php
// Título de la página
$titulo_pagina = "Dashboard";
 
// Obtener estadísticas generales (código igual)
$stats_query = "
SELECT 
(SELECT COUNT(*) FROM proveedores WHERE status = 1" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS proveedores_activos,
(SELECT COUNT(*) FROM clientes WHERE status = 1" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS clientes_activos,
(SELECT COUNT(*) FROM transportes WHERE status = 1" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS transportes_activos,
(SELECT COUNT(*) FROM productos WHERE status = 1" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS productos_activos,
(SELECT COUNT(*) FROM recoleccion WHERE status = 1 AND MONTH(fecha_r) = MONTH(CURRENT_DATE())" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS recolecciones_mes,


(SELECT COUNT(*) FROM recoleccion WHERE status = 1 AND remision IS NOT NULL AND factura_fle IS NOT NULL" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS recolecciones_completas,


(SELECT COUNT(*) FROM recoleccion WHERE status = 1 AND (remision IS NULL OR factura_fle IS NULL)" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : "") . ") AS recolecciones_pendientes
";

$stats = $conn_mysql->query($stats_query)->fetch_assoc();

// AVISOS IMPORTANTES (código igual)
$precios_caducando = $conn_mysql->query("SELECT COUNT(*) as total FROM precios WHERE status = 1 AND fecha_fin BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)" . ($zona_seleccionada != '0' ? " AND id_prod IN (SELECT id_prod FROM productos WHERE zona = '$zona_seleccionada')" : ""));
$aviso_precios = $precios_caducando->fetch_assoc()['total'] ?? 0;

$productos_sin_precio = $conn_mysql->query("SELECT COUNT(DISTINCT p.id_prod) as total FROM productos p LEFT JOIN precios pr ON p.id_prod = pr.id_prod AND pr.status = 1 AND pr.fecha_ini <= CURDATE() AND (pr.fecha_fin >= CURDATE() OR pr.fecha_fin IS NULL) WHERE p.status = 1 AND pr.id_precio IS NULL" . ($zona_seleccionada != '0' ? " AND p.zona = '$zona_seleccionada'" : ""));
$aviso_sin_precio = $productos_sin_precio->fetch_assoc()['total'] ?? 0;

$fleteros_sin_correo = $conn_mysql->query("SELECT COUNT(*) as total FROM transportes WHERE status = 1 AND (correo IS NULL OR correo = '' OR correo = '0')" . ($zona_seleccionada != '0' ? " AND zona = '$zona_seleccionada'" : ""));
$aviso_fleteros = $fleteros_sin_correo->fetch_assoc()['total'] ?? 0;

// Obtener nombre de zona si está filtrada
$nombre_zona = '';
if($zona_seleccionada != '0') {
    $zona_query = $conn_mysql->query("SELECT nom FROM zonas WHERE id_zone = '$zona_seleccionada'");
    $zona_data = mysqli_fetch_array($zona_query);
    $nombre_zona = $zona_data['nom'] ?? '';
}

// Obtener últimas recolecciones (código igual) 
$ultimasRecolecciones = $conn_mysql->query("
    SELECT r.id_recol, r.folio, r.fecha_r, r.factura_v, 
    p.rs AS proveedor, c.nombre AS cliente, t.razon_so AS fletero,
    pr.nom_pro AS producto, z.cod AS cod_zona,
    r.remision, r.factura_fle, r.status
    FROM recoleccion r
    LEFT JOIN proveedores p ON r.id_prov = p.id_prov
    LEFT JOIN clientes c ON r.id_cli = c.id_cli
    LEFT JOIN transportes t ON r.id_transp = t.id_transp
    LEFT JOIN producto_recole prc ON r.id_recol = prc.id_recol
    LEFT JOIN productos pr ON prc.id_prod = pr.id_prod
    LEFT JOIN zonas z ON r.zona = z.id_zone
    WHERE r.status = '1'" . ($zona_seleccionada != '0' ? " AND r.zona = '$zona_seleccionada'" : "") . "
    ORDER BY r.fecha_r DESC, r.id_recol DESC LIMIT 5");


// CONSULTA PARA RECOLECCIONES CON FACTURA FLETE RECHAZADA
$recolecciones_rechazadas = $conn_mysql->query("
    SELECT 
        r.id_recol,
        r.folio,
        r.fecha_r,
        z.cod AS cod_zona,
        p.rs AS proveedor,
        t.razon_so AS fletero,
        r.FacFexis AS contador_rechazos
    FROM recoleccion r
    LEFT JOIN zonas z ON r.zona = z.id_zone
    LEFT JOIN proveedores p ON r.id_prov = p.id_prov
    LEFT JOIN transportes t ON r.id_transp = t.id_transp
    WHERE r.status = '1' 
    AND r.factura_fle IS NULL 
    AND r.FacFexis > 0
    " . ($zona_seleccionada != '0' ? " AND r.zona = '$zona_seleccionada'" : "") . "
    ORDER BY r.FacFexis DESC, r.fecha_r DESC
    LIMIT 10
");

$total_rechazadas = $recolecciones_rechazadas->num_rows;
    ?>
    <div class="container py-4">

        <!-- SECCIÓN DE AVISOS IMPORTANTES COMPACTADA -->
        <?php if ($aviso_precios > 0 || $aviso_sin_precio > 0 || $aviso_fleteros > 0): ?>
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card border-warning bg-warning bg-opacity-10 shadow-sm">
                        <div class="card-body py-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-exclamation-triangle-fill text-warning me-2 fs-5"></i>
                                    <h6 class="mb-0">Avisos Importantes</h6>
                                </div>

                                <div class="d-flex flex-wrap gap-4">
                                    <?php if ($aviso_precios > 0): ?>
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-warning me-2"><?= $aviso_precios ?></span>
                                            <small class="text-muted">Precios por caducar</small>
                                            <a href="?p=productos" class="text-warning ms-2 small">
                                                <i class="bi bi-arrow-right-short"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($aviso_sin_precio > 0): ?>
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-danger me-2"><?= $aviso_sin_precio ?></span>
                                            <small class="text-muted">Productos sin precio</small>
                                            <a href="?p=productos" class="text-danger ms-2 small">
                                                <i class="bi bi-arrow-right-short"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($aviso_fleteros > 0): ?>
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-info me-2"><?= $aviso_fleteros ?></span>
                                            <small class="text-muted">Fleteros sin correo</small>
                                            <a href="?p=transportes" class="text-info ms-2 small">
                                                <i class="bi bi-arrow-right-short"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- SECCIÓN DE ALERTAS DE FACTURAS FLETE RECHAZADAS -->
<?php if ($total_rechazadas > 0): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-danger shadow-sm">
            <div class="card-header bg-danger bg-opacity-10 py-2">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-octagon-fill text-danger me-2"></i>
                        <h6 class="mb-0 text-danger">Facturas de Flete Rechazadas</h6>
                        <span class="badge bg-danger ms-2"><?= $total_rechazadas ?></span>
                    </div>
                    <small class="text-muted">Requieren atención inmediata</small>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" width="120">Folio</th>
                                <th width="100">Fecha</th>
                                <th>Proveedor</th>
                                <th>Fletero</th>
                                <th width="100" class="text-center">Rechazos</th>
                                <th width="100" class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($rechazada = $recolecciones_rechazadas->fetch_assoc()): 
                                $folio_completo = $rechazada['cod_zona'] . "-" . date('ym', strtotime($rechazada['fecha_r'])) . str_pad($rechazada['folio'], 4, '0', STR_PAD_LEFT);
                                $fecha_formateada = date('d/m/Y', strtotime($rechazada['fecha_r']));
                                ?>
                                <tr>
                                    <td class="ps-3">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-danger bg-opacity-10 p-1 rounded me-2">
                                                <i class="bi bi-file-earmark-x text-danger"></i>
                                            </div>
                                            <strong class="small"><?= htmlspecialchars($folio_completo) ?></strong>
                                        </div>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= $fecha_formateada ?></small>
                                    </td>
                                    <td>
                                        <small><?= htmlspecialchars($rechazada['proveedor']) ?></small>
                                    </td>
                                    <td>
                                        <small><?= htmlspecialchars($rechazada['fletero']) ?></small>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-danger">
                                            <?= $rechazada['contador_rechazos'] ?> 
                                            <?= $rechazada['contador_rechazos'] == 1 ? 'vez' : 'veces' ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="?p=V_recoleccion&id=<?= $rechazada['id_recol'] ?>" 
                                           target="_blank" 
                                           class="btn btn-sm btn-outline-danger"
                                           title="Ver recolección">
                                           <i class="bi bi-pencil-square"></i> Corregir
                                       </a>
                                   </td>
                               </tr>
                           <?php endwhile; ?>
                       </tbody>
                   </table>
               </div>
           </div>
           <div class="card-footer bg-opacity-10 bg-danger py-2">
               <div class="d-flex justify-content-between align-items-center">
                   <small class="text-muted">
                       <i class="bi bi-info-circle me-1"></i>
                       Facturas rechazadas en sistema INVOICE - Requieren nueva factura
                   </small>
                   <a href="?p=recoleccion" class="btn btn-sm btn-outline-danger">
                       Ver todas <i class="bi bi-arrow-right ms-1"></i>
                   </a>
               </div>
           </div>
       </div>
   </div>
</div>
<?php endif; ?>

        <!-- TARJETAS DE MÉTRICAS REORGANIZADAS -->
        <div class="row mb-4 g-3">
            <?php 
        // Agrupar tarjetas en categorías lógicas
            $metricas_entidades = [
                ['link' => 'proveedores', 'titulo' => 'Proveedores', 'valor' => $stats['proveedores_activos'], 'icono' => 'building', 'color' => 'primary'],
                ['link' => 'clientes', 'titulo' => 'Clientes', 'valor' => $stats['clientes_activos'], 'icono' => 'people-fill', 'color' => 'success'],
                ['link' => 'transportes', 'titulo' => 'Transportes', 'valor' => $stats['transportes_activos'], 'icono' => 'truck', 'color' => 'purple'],
                ['link' => 'productos', 'titulo' => 'Productos', 'valor' => $stats['productos_activos'], 'icono' => 'box-seam', 'color' => 'orange'],
            ];

            $metricas_recolecciones = [
                ['link' => 'recoleccion', 'titulo' => 'Este Mes', 'valor' => $stats['recolecciones_mes'], 'icono' => 'calendar-check', 'color' => 'purple'],
                ['link' => 'recoleccion', 'titulo' => 'Completadas', 'valor' => $stats['recolecciones_completas'], 'icono' => 'check-circle', 'color' => 'teal'],
                ['link' => 'recoleccion', 'titulo' => 'Pendientes', 'valor' => $stats['recolecciones_pendientes'], 'icono' => 'clock', 'color' => 'indigo'],
            ];
            ?>

            <!-- Entidades Principales -->
            <div class="col-lg-8">
                <div class="card shadow-sm h-100">
                    <div class="card-header py-2">
                        <h6 class="mb-0"><i class="bi bi-grid-3x3-gap me-2"></i>Entidades Principales</h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <?php foreach ($metricas_entidades as $metrica): ?>
                                <div class="col-md-3 col-6">
                                    <a href="?p=<?=$metrica['link']?>" class="text-decoration-none">
                                        <div class="card border-<?= $metrica['color'] ?> shadow-sm h-100 hover-scale">
                                            <div class="card-body text-center p-3">
                                                <div class="bg-<?= $metrica['color'] ?> bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                                    <i class="bi bi-<?= $metrica['icono'] ?> text-<?= $metrica['color'] ?> fs-5"></i>
                                                </div>
                                                <h5 class="text-<?= $metrica['color'] ?> mb-1"><?= $metrica['valor'] ?></h5>
                                                <p class="text-muted small mb-0"><?= $metrica['titulo'] ?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Resumen Recolecciones -->
            <div class="col-lg-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header py-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-0"><i class="bi bi-clipboard-data me-2"></i>Recolecciones</h6>
                            <a href="?p=recoleccion" class="text-decoration-none small">
                                Ver todas <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Botón principal destacado -->
                        <div class="d-grid mb-3">
                            <a href="?p=N_recoleccion" class="btn btn-primary" target="_blank" <?= $perm['Recole_Crear'];?>>
                                <i class="bi bi-plus-circle me-2"></i>Crear Nueva Recolección
                            </a>
                        </div>
                        <?php foreach ($metricas_recolecciones as $metrica): ?>
                            <a href="?p=<?=$metrica['link']?>" class="text-decoration-none">
                                <div class="d-flex align-items-center justify-content-between mb-3 p-2 rounded hover-item">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-<?= $metrica['color'] ?> bg-opacity-10 p-2 rounded me-3 border border-<?= $metrica['color'] ?>">
                                            <i class="bi bi-<?= $metrica['icono'] ?> text-<?= $metrica['color'] ?>"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 text-<?= $metrica['color'] ?>"><?= $metrica['valor'] ?></h6>
                                            <small class="text-muted"><?= $metrica['titulo'] ?></small>
                                        </div>
                                    </div>
                                    <i class="bi bi-chevron-right text-muted"></i>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- REPORTE FINANCIERO (igual que antes) -->
        <div class="mb-4 g-4">
            <div class="card shadow-sm mb-3">
                <h6 class="card-header">Reporte de Recolección <?=$nombre_zona?></h6>
                <div class="card-body">
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <input id="dt_mvI" type="date" class="form-control" name="dt_mvI" value="<?= date('Y-m-01') ?>" max="<?= date('Y-m-d') ?>" style="width: 160px;">
                        <input id="dt_mvF" type="date" class="form-control" name="dt_mvF" value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" style="width: 160px;">
                        <input type="hidden" name="zona" id="zona" value="<?=$zona_seleccionada?>">
                        <button class="btn btn-sm btn-primary px-3" onclick="pre1()">
                            <i class="bi bi-search me-1"></i> Buscar
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4 g-4" id="res1">
            <!-- Contenido cargado via AJAX -->
        </div>

        <!-- ÚLTIMAS RECOLECCIONES (igual que antes) -->
        <div class="row g-4">
            <div class="col-12">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-0">Últimas Recolecciones</h6>
                            <a href="?p=recoleccion" class="btn btn-sm btn-secondary">
                                Ver todas <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table table-info table-striped">
                                    <tr>
                                        <th class="ps-4">Folio</th>
                                        <th>Proveedor</th>
                                        <th>Cliente</th>
                                        <th>Fletero</th>
                                        <th>Producto</th>
                                        <th>Estado</th>
                                        <th class="text-center">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($recoleccion = $ultimasRecolecciones->fetch_assoc()): 
                                        $folio_completo = $recoleccion['cod_zona'] . "-" . date('ym', strtotime($recoleccion['fecha_r'])) . str_pad($recoleccion['folio'], 4, '0', STR_PAD_LEFT);
                                        $estado_completo = ($recoleccion['remision'] && $recoleccion['factura_fle']) ? 'Completa' : 'Pendiente';
                                        $color_estado = ($recoleccion['remision'] && $recoleccion['factura_fle']) ? 'success' : 'warning';
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="bg-info bg-opacity-10 p-1 rounded me-2">
                                                        <i class="bi bi-clipboard-data text-info"></i>
                                                    </div>
                                                    <?= htmlspecialchars($folio_completo) ?>
                                                </div>
                                            </td>
                                            <td>
                                                <small><?= htmlspecialchars($recoleccion['proveedor']) ?></small>
                                            </td>
                                            <td>
                                                <small><?= htmlspecialchars($recoleccion['cliente']) ?></small>
                                            </td>
                                            <td>
                                                <small><?= htmlspecialchars($recoleccion['fletero']) ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-indigo bg-opacity-10 text-indigo small">
                                                    <?= htmlspecialchars($recoleccion['producto']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?= $color_estado ?> small">
                                                    <?= $estado_completo ?>
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <a href="?p=V_recoleccion&id=<?= $recoleccion['id_recol'] ?>" 
                                                   target="_blank" 
                                                   class="btn btn-sm btn-outline-primary"
                                                   title="Abrir en nueva ventana">
                                                   <i class="bi bi-box-arrow-up-right"></i>
                                               </a>
                                           </td>
                                       </tr>
                                   <?php endwhile; ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>

   <style>
    .hover-scale {
        transition: transform 0.2s ease;
    }
    .hover-scale:hover {
        transform: translateY(-2px);
    }
    .hover-item {
        transition: all 0.2s ease;
    }
    .hover-item:hover {
        background-color: var(--bs-secondary-bg);
        transform: translateX(5px);
    }
</style>

<script>
    // (El mismo código JavaScript)
    function pre1(){
        dt_mvI = document.getElementById('dt_mvI').value;
        dt_mvF = document.getElementById('dt_mvF').value;
        zona = document.getElementById('zona').value;

        var parametros = {
            "dt_mvI" : dt_mvI,
            "dt_mvF" : dt_mvF,
            "zona" : zona
        };

        $.ajax({
            data: parametros,
            url: 'reporte_ini.php',
            type: 'POST',
            beforeSend: function() {
                $('#res1').html('<div class="text-center"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Cargando reporte...</p></div>');
            },
            success: function(mensaje) {
                $('#res1').html(mensaje);
            },
            error: function() {
                $('#res1').html('<div class="alert alert-danger">Error al cargar el reporte</div>');
            }
        });
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        pre1();
    });
</script>