<?php
// N_direccion.php - Nueva Bodega

// Obtener ID del Cliente
$id_cliente = clear($_GET['id'] ?? '');

// Obtener datos del cliente para mostrar su información
$cliente = [];
if ($id_cliente) {
    $sqlCliente = "SELECT cod, nombre, rs FROM clientes WHERE id_cli = ?";
    $stmtCliente = $conn_mysql->prepare($sqlCliente);
    $stmtCliente->bind_param('i', $id_cliente);
    $stmtCliente->execute();
    $resultCliente = $stmtCliente->get_result();
    $cliente = $resultCliente->fetch_assoc();
}

if (isset($_POST['guardarDireccion'])) {

    $cod_al1 = $_POST['cod_al'] ?? '';

    $AlertCo02 = $conn_mysql->query("SELECT * FROM direcciones WHERE cod_al = '$cod_al1' AND status = '1'");
    $AlertCo03 = mysqli_fetch_array($AlertCo02);

    if (!empty($AlertCo03['id_direc'])) {
        alert("codigo ya ocupada", 2, "N_direccion&id=$id_cliente");  
    }else {

        try {
            $BodegaData = [
                'cod_al' => $_POST['cod_al'] ?? '',
                'noma' => $_POST['noma'] ?? '',
                'atencion' => $_POST['atencion'] ?? '',
                'tel' => $_POST['tel'] ?? '',
                'email' => $_POST['email'] ?? '',
                'obs' => $_POST['obs'] ?? '',
                'id_us' => $id_cliente
            ];

        // Insertar bodega
            $columns = implode(', ', array_keys($BodegaData));
            $placeholders = str_repeat('?,', count($BodegaData) - 1) . '?';
            $sql = "INSERT INTO direcciones ($columns) VALUES ($placeholders)";
            $stmt = $conn_mysql->prepare($sql);

            $types = str_repeat('s', count($BodegaData));
            $stmt->bind_param($types, ...array_values($BodegaData));
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                alert("Bodega agregada exitosamente", 1, "V_cliente&id=$id_cliente");
                logActivity('CREAR', 'Dio de alta una nueva bodega para el cliente '. $id_cliente);
            } else {
                alert("Error al registrar la bodega", 0, "N_direccion&id=$id_cliente");
            }
        } catch (mysqli_sql_exception $e) {
            alert("Error: " . $e->getMessage(), 0, "N_direccion&id=$id_cliente");
        }
    }
}
?>

<div class="container mt-2">
    <div class="card shadow-sm">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Nueva Bodega para: <?= htmlspecialchars($cliente['nombre'] ?? '') ?></h5>
            <a href="?p=V_cliente&id=<?= $id_cliente ?>">
                <button type="button" class="btn btn-sm btn-danger">Cancelar</button>
            </a>
        </div>
        <div class="card-body">
            <form class="forms-sample" method="post" action="">
                <!-- Información del cliente (solo lectura) -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <label class="form-label">Código Cliente</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($cliente['cod'] ?? '') ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Nombre</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($cliente['nombre'] ?? '') ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Razón Social</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($cliente['rs'] ?? '') ?>" readonly>
                    </div>
                </div>

                <!-- Campos de la bodega -->
                <div class="form-section">
                    <h5 class="section-header">Información de la Bodega</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="cod_al" class="form-label">Código de Bodega <span id="resulpostal00"></span></label>
                            <input name="cod_al" type="text" class="form-control" id="cod_al" oninput="codigo1()">
                        </div>
                        <div class="col-md-6">
                            <label for="noma" class="form-label">Nombre de Bodega</label>
                            <input name="noma" type="text" class="form-control" id="noma">
                        </div>
                        <div class="col-md-6">
                            <label for="atencion" class="form-label">Atención</label>
                            <input name="atencion" type="text" class="form-control" value="N/S" id="atencion">
                        </div>
                        <div class="col-md-3">
                            <label for="tel" class="form-label">Teléfono</label>
                            <input name="tel" type="tel" class="form-control" value="55 5555 5555" id="tel">
                        </div>
                        <div class="col-md-3">
                            <label for="email" class="form-label">Email</label>
                            <input name="email" type="email" class="form-control" id="email">
                        </div>
                        <div class="col-12">
                            <label for="obs" class="form-label">Observaciones</label>
                            <textarea name="obs" class="form-control" id="obs" rows="3"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Botones de acción -->
                <div class="d-flex justify-content-md-end mt-4">
                    <button type="submit" name="guardarDireccion" class="btn btn-primary">Guardar Bodega</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function codigo1() {
        var cod_al = document.getElementById('cod_al').value;

        var parametros = {
            "cod_al": cod_al,
        };

        console.log(parametros);

        $.ajax({
            data: parametros,
            url: 'cd_php.php',
            type: 'POST',
            beforeSend: function () {
                $('#resulpostal00').html("");
            },
            success: function (mensaje) {
                $('#resulpostal00').html(mensaje);
            }
        });
    }
</script>