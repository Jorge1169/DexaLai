<?php
$id_transporte = clear($_GET['id'] ?? '');
if ($id_transporte) {
	$sqltransp = "SELECT * FROM transportes WHERE id_transp = ?";
	$stmttransporte = $conn_mysql->prepare($sqltransp);
	$stmttransporte->bind_param('i', $id_transporte);
	$stmttransporte->execute();
	$resulttransporte = $stmttransporte->get_result();
	$transp = $resulttransporte->fetch_assoc();
} 
// Procesar eliminación de precio (cambiar status a 0)
if (isset($_POST['eliminar_precio'])) {
    $id_precio = $_POST['id_precio']; 
    $sqlEliminar = "UPDATE precios SET status = 0 WHERE id_precio = ?";
    $stmtEliminar = $conn_mysql->prepare($sqlEliminar);
    $stmtEliminar->bind_param('i', $id_precio);
    $stmtEliminar->execute();

    if ($stmtEliminar->affected_rows > 0) {
        alert("Precio eliminado con éxito", 1, "V_transporte&id=".$id_transporte."");
        logActivity('PRECIO', "Elimino el precio del fletero ". $id_transporte);
    } else {
        alert("Error al eliminar el precio", 2, "V_transporte&id=".$id_transporte."");
    } 
}

if (isset($_POST['guardar01'])) {

	$fecha_Ini = $_POST['fechaini'] ?? date('Y-m-d');
	if (!DateTime::createFromFormat('Y-m-d', $fecha_Ini)) {
		alert("Formato de fecha inválido. Use YYYY-MM-DD", 2, "N_compra");
		exit;
	}

	$fecha_Fin = $_POST['fechafin'] ?? date('Y-m-d');
	if (!DateTime::createFromFormat('Y-m-d', $fecha_Fin)) {
		alert("Formato de fecha inválido. Use YYYY-MM-DD", 2, "N_compra");
		exit;
	}
	$PrecioData = [
		'id_prod' => $id_transporte,
		'precio' => $_POST['precio'],
		'tipo' => $_POST['tipo'],
        'origen' => $_POST['origen'],
        'destino' => $_POST['destino'],
        'conmin' => $_POST['conmin'],
        'fecha_ini' => $fecha_Ini,
        'fecha_fin' => $fecha_Fin,
        'usuario' => $idUser,
        'status' => 1

    ];
    $columns = implode(', ', array_keys($PrecioData));
    $placeholders = str_repeat('?,', count($PrecioData) - 1) . '?';
    $sql = "INSERT INTO precios ($columns) VALUES ($placeholders)";
    $stmt = $conn_mysql->prepare($sql);
    $types = str_repeat('s', count($PrecioData));
    $stmt->bind_param($types, ...array_values($PrecioData));
    $stmt->execute();


    if ($stmt->affected_rows <= 0) {
      throw new Exception("Error al registrar la compra");
  }

  alert("Precio Registrado con exito",1,"V_transporte&id=".$id_transporte."");
  logActivity('PRECIO', "Registro precio de flete para el fletero ". $id_transporte);
}
?>

<div class="container mt-2">
    <div class="card mb-4">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-0">Datos del transportista</h5>
                <span class="small">Código: <?=$transp['placas']?></span>
            </div>
            <div class="d-flex gap-2">
                <a href="?p=transportes" class="btn btn-sm rounded-3 btn-outline-light">
                    <i class="bi bi-arrow-left me-1"></i> Regresar
                </a>
                <a href="?p=E_transportista&id=<?=$id_transporte?>" class="btn btn-sm rounded-3 btn-light" <?= $perm['Clien_Editar'];?>>
                    <i class="bi bi-pencil me-1"></i> Editar
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 col-12 mb-4">
                    <div class="card">
                        <div class="card-header">
                            Información del transportista <i class="bi bi-box-seam text-primary"></i>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    R. social
                                    <span class="badge text-body"><?=$transp['razon_so']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Codigo
                                    <span class="badge text-body"><?=$transp['placas']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Linea
                                    <span class="badge text-body"><?=$transp['linea']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Tipo
                                    <span class="badge text-body"><?=$transp['tipo']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Correo
                                    <span class="badge text-body"><?=$transp['correo']?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-12">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span>Precios <i class="bi bi-cash-stack text-teal"></i></span>
                            <button <?= $perm['sub_precios'];?> type="button" class="btn btn-success btn-sm rounded-3" data-bs-toggle="modal" data-bs-target="#AgregarPrec">
                                <i class="bi bi-plus-circle me-1"></i> Agregar
                            </button>
                        </div>
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">Precios de flete</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead>
                                        <tr>
                                            <th>Precio</th>
                                            <th>Ruta</th>
                                            <th>Peso Mín.</th>
                                            <th>Vigencia</th>
                                            <th>Estado</th>
                                            <th width="80">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                        // Función para determinar el estado de vigencia
                                        function obtenerEstadoVigencia($fecha_fin) {
                                            $hoy = date('Y-m-d');
                                            $tres_dias = date('Y-m-d', strtotime('+3 days'));
                                            
                                            if ($fecha_fin < $hoy) {
                                                return [
                                                    'estado' => 'caducado',
                                                    'texto' => 'Caducado',
                                                    'clase' => 'bg-danger',
                                                    'icono' => 'bi-exclamation-triangle',
                                                    'tooltip' => 'Este precio ha caducado'
                                                ];
                                            } elseif ($fecha_fin <= $tres_dias) {
                                                return [
                                                    'estado' => 'por_caducar',
                                                    'texto' => 'Por caducar',
                                                    'clase' => 'bg-warning',
                                                    'icono' => 'bi-clock',
                                                    'tooltip' => 'Caduca en menos de 3 días'
                                                ];
                                            } else {
                                                return [
                                                    'estado' => 'vigente',
                                                    'texto' => 'Vigente',
                                                    'clase' => 'bg-success',
                                                    'icono' => 'bi-check-circle',
                                                    'tooltip' => 'Precio vigente'
                                                ];
                                            }
                                        }

                                        $PreciFle00 = $conn_mysql->query("
                                            SELECT p.*, 
                                            o.cod_al as cod_origen, o.noma as nom_origen,
                                            d.cod_al as cod_destino, d.noma as nom_destino
                                            FROM precios p
                                            LEFT JOIN direcciones o ON p.origen = o.id_direc
                                            LEFT JOIN direcciones d ON p.destino = d.id_direc
                                            WHERE (p.tipo = 'FT' OR p.tipo = 'FV') AND p.status = '1' AND p.id_prod = '$id_transporte'
                                            ORDER BY p.fecha_ini DESC, p.fecha_fin DESC
                                            ");

                                        while ($PreciFle01 = mysqli_fetch_array($PreciFle00)) {
                                            $tipo_texto = ($PreciFle01['tipo'] == 'FT') ? 'Por tonelada' : 'Por viaje';
                                            $peso_minimo = $PreciFle01['conmin'] > 0 ? $PreciFle01['conmin'] . ' ton' : '';
                                            $tipo_badge = ($PreciFle01['tipo'] == 'FT') ? 'bg-primary' : 'bg-success';
                                            
                            // Obtener estado de vigencia
                                            $estadoVigencia = obtenerEstadoVigencia($PreciFle01['fecha_fin']);
                                            
                            // Calcular días restantes
                                            $hoy = new DateTime();
                                            $fechaFin = new DateTime($PreciFle01['fecha_fin']);
                                            $diasRestantes = $hoy->diff($fechaFin)->days;
                                            $diasTexto = $diasRestantes == 1 ? '1 día' : "$diasRestantes días";
                                            
                            // Determinar clase para la fila según el estado
                                            $claseFila = '';
                                            if ($estadoVigencia['estado'] == 'caducado') {
                                                $claseFila = 'table-danger';
                                            } elseif ($estadoVigencia['estado'] == 'por_caducar') {
                                                $claseFila = 'table-warning';
                                            }
                                            ?>
                                            <tr class="<?= $claseFila ?>">
                                                <td>
                                                    <span class="fw-semibold">$<?= number_format($PreciFle01['precio'], 2) ?></span>
                                                    <br>
                                                    <span class="badge <?= $tipo_badge ?>"><?= $tipo_texto ?></span>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <small class="text-primary me-1">
                                                            <i class="bi bi-geo-alt-fill"></i> <?= htmlspecialchars($PreciFle01['cod_origen']) ?>
                                                        </small>
                                                        <i class="bi bi-arrow-right text-muted mx-1"></i>
                                                        <small class="text-success">
                                                            <i class="bi bi-geo-alt"></i> <?= htmlspecialchars($PreciFle01['cod_destino']) ?>
                                                        </small>
                                                    </div>
                                                    <div class="small text-muted">
                                                        <?= htmlspecialchars($PreciFle01['nom_origen']) ?> → <?= htmlspecialchars($PreciFle01['nom_destino']) ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="badge bg-light text-dark border"><?= $peso_minimo ?></span>
                                                </td>
                                                <td>
                                                    <div class="small">
                                                        <div class="fw-semibold">
                                                            <?= date('d/m/Y', strtotime($PreciFle01['fecha_ini'])) ?> - 
                                                            <?= date('d/m/Y', strtotime($PreciFle01['fecha_fin'])) ?>
                                                        </div>
                                                        <?php if ($estadoVigencia['estado'] != 'caducado'): ?>
                                                            <div class="text-muted">
                                                                <small>
                                                                    <i class="bi bi-calendar me-1"></i>
                                                                    <?= $diasTexto ?> restantes
                                                                </small>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge badge-estado-precio <?= $estadoVigencia['clase'] ?>" 
                                                      title="<?= $estadoVigencia['tooltip'] ?>"
                                                      data-bs-toggle="tooltip" data-bs-placement="top">
                                                      <i class="bi <?= $estadoVigencia['icono'] ?> me-1"></i>
                                                      <?= $estadoVigencia['texto'] ?>
                                                  </span>
                                              </td>
                                              <td>
                                                <button <?= $perm['sub_precios'];?> type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalEliminarPrecio" 
                                                data-precio-id="<?= $PreciFle01['id_precio'] ?>" 
                                                data-precio-valor="$<?= number_format($PreciFle01['precio'], 2) ?>"
                                                data-precio-estado="<?= $estadoVigencia['estado'] ?>">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                if(mysqli_num_rows($PreciFle00) == 0): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">
                                            <i class="bi bi-info-circle me-2"></i>
                                            No hay precios de flete registrados
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Resumen de estados -->
                    <div class="mt-3 p-3 bg-body-tertiary rounded">
                        <h6 class="mb-2"><i class="bi bi-info-circle me-2"></i>Leyenda de estados:</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-success">
                                <i class="bi bi-check-circle me-1"></i>Vigente
                            </span>
                            <span class="badge bg-warning">
                                <i class="bi bi-clock me-1"></i>Por caducar (≤ 3 días)
                            </span>
                            <span class="badge bg-danger">
                                <i class="bi bi-exclamation-triangle me-1"></i>Caducado
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
</div>
</div>

<!-- Modal para nuevo precio -->
<div class="modal fade" id="AgregarPrec" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form class="forms-sample" method="post" action="">
                <div class="modal-header text-bg-success">
                    <h5 class="modal-title" id="exampleModalLabel">
                        <i class="bi bi-tag me-2"></i> Nuevo precio
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-lg-6">
                            <label for="tipo" class="form-label">Tipo</label>
                            <select class="form-select" name="tipo" id="tipo" required>
                                <option value="FT">Por tonelada</option>
                                <option value="FV">Por viaje</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="precio" class="form-label">Precio $</label>
                            <input type="number" step="0.01" min="0" name="precio" id="precio" class="form-control" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="origen" class="form-label">Origen</label>
                            <select class="form-select" name="origen" id="origen">
                                <option selected disabled value="">Selecciona un Origen...</option>
                                <?php
                                $ori0 = $conn_mysql->query("SELECT * FROM direcciones where status = '1' AND id_prov is not null order by cod_al");
                                while ($ori1 = mysqli_fetch_array($ori0)) {
                                    ?>
                                    <option value="<?=$ori1['id_direc']?>"><?=$ori1['cod_al']." (".$ori1['noma'].")"?></option>
                                    <?php  
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="destino" class="form-label">Destino</label>
                            <select class="form-select" name="destino" id="destino">
                                <option selected disabled value="">Selecciona un Destino...</option>
                                <?php
                                $des0 = $conn_mysql->query("SELECT * FROM direcciones where status = '1' AND id_us is not null order by cod_al");
                                while ($des1 = mysqli_fetch_array($des0)) {
                                    ?>
                                    <option value="<?=$des1['id_direc']?>"><?=$des1['cod_al']." (".$des1['noma'].")"?></option>
                                    <?php  
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="conmin" class="form-label">* Peso minimo (En toneladas)</label>
                            <input type="number" step="0.01" min="0" name="conmin" value="0" id="conmin" class="form-control">
                        </div>
                        <div class="col-lg-4">
                            <label for="fechaini" class="form-label">Fecha de Inicio</label>
                            <input type="date" value="<?= date('Y-m-01') ?>" name="fechaini" id="fechaini" class="form-control" required>
                        </div>
                        <div class="col-lg-4">
                            <label for="fechafin" class="form-label">Fecha Final</label>
                            <input type="date" value="<?= date('Y-m-d') ?>" name="fechafin" id="fechafin" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary rounded-3 btn-sm" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Cancelar
                    </button>
                    <button type="submit" name="guardar01" class="btn btn-success rounded-3 btn-sm">
                        <i class="bi bi-check-circle me-1"></i> Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('#origen').select2({
            placeholder: "Selecciona o busca una opción",
            allowClear: true,
            language: "es",
            dropdownParent: $('#AgregarPrec'),
            width: '100%' // Esta línea es importante
        });
        
        $('#destino').select2({
            placeholder: "Selecciona o busca una opción",
            allowClear: true,
            language: "es",
            dropdownParent: $('#AgregarPrec'),
            width: '100%' // Esta línea es importante
        });
    });
</script>
<!-- Modal único para eliminar precio -->
<div class="modal fade" id="modalEliminarPrecio" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form class="forms-sample" method="post" action="">
                <div class="modal-header text-bg-danger">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Eliminar precio</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>¿Estás seguro de eliminar el precio <span id="precio-valor" class="fw-bold"></span>?</p>
                    <input type="hidden" name="id_precio" id="id-precio-eliminar">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm rounded-3" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" name="eliminar_precio" class="btn btn-danger btn-sm rounded-3">Eliminar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Script para manejar el modal de eliminación
    document.addEventListener('DOMContentLoaded', function() {
        const modalEliminar = document.getElementById('modalEliminarPrecio');

        modalEliminar.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const precioId = button.getAttribute('data-precio-id');
            const precioValor = button.getAttribute('data-precio-valor');

            document.getElementById('id-precio-eliminar').value = precioId;
            document.getElementById('precio-valor').textContent = precioValor;
        });
    });
</script>