<?php
$id_producto = clear($_GET['id'] ?? '');
if ($id_producto) {
    // datos del producto 
    $sqlproducto = "SELECT * FROM productos WHERE id_prod = ?";
    $stmtproducto = $conn_mysql->prepare($sqlproducto);
    $stmtproducto->bind_param('i', $id_producto);
    $stmtproducto->execute();
    $resultProducto = $stmtproducto->get_result();
    $producto = $resultProducto->fetch_assoc();
}

// Procesar eliminación de precio (cambiar status a 0)
if (isset($_POST['eliminar_precio'])) {
    $id_precio = $_POST['id_precio']; 
    $sqlEliminar = "UPDATE precios SET status = 0 WHERE id_precio = ?";
    $stmtEliminar = $conn_mysql->prepare($sqlEliminar);
    $stmtEliminar->bind_param('i', $id_precio);
    $stmtEliminar->execute();

    if ($stmtEliminar->affected_rows > 0) {
        alert("Precio eliminado con éxito", 1, "V_producto&id=".$id_producto."");
        logActivity('PRECIO', 'Elimino el precio ' . $id_producto);
    } else {
        alert("Error al eliminar el precio", 2, "V_producto&id=".$id_producto."");
        logActivity('PRECIO', 'Intento elimino el precio ' . $id_producto);
    }
}
if (isset($_POST['guardar01'])) {
    // Si es compra, forzar destino = 0
    if ($_POST['tipo'] == 'c') {
        $PlantaV = 0;
    } else {
        $PlantaV = $_POST['planta'] ?? 0;
    }

    $fecha_Ini = $_POST['fechaini'] ?? date('Y-m-d');
    if (!DateTime::createFromFormat('Y-m-d', $fecha_Ini)) {
        alert("Formato de fecha inválido. Use YYYY-MM-DD", 2, "N_compra");
        exit;
    }

    $fecha_Fin = $_POST['fechafin'] ?? date('Y-m-d');
    if (!DateTime::createFromFormat('Y-m-d', $fecha_Fin)) {
        alert("Formato de fecha inválido. Use YYYY-MM-DD", 2, "N_compra");
        exit;
    }
    
    // VERIFICAR si ya existe un precio activo con el mismo tipo, producto, precio Y DESTINO
    $sql_verificar = "SELECT id_precio FROM precios 
    WHERE id_prod = ? 
    AND tipo = ? 
    AND precio = ?
    AND destino = ?
    AND status = '1'";
    $stmt_verificar = $conn_mysql->prepare($sql_verificar);
    $stmt_verificar->bind_param('isdi', $id_producto, $_POST['tipo'], $_POST['precio'], $PlantaV);
    $stmt_verificar->execute();
    $result_verificar = $stmt_verificar->get_result();
    
    if ($result_verificar->num_rows > 0) {
        // Ya existe un precio con los mismos datos → ACTUALIZAR FECHAS
        $precio_existente = $result_verificar->fetch_assoc();
        $sql_actualizar = "UPDATE precios SET fecha_ini = ?, fecha_fin = ?, usuario = ? 
        WHERE id_precio = ?";
        $stmt_actualizar = $conn_mysql->prepare($sql_actualizar);
        $stmt_actualizar->bind_param('ssii', $fecha_Ini, $fecha_Fin, $idUser, $precio_existente['id_precio']);
        $stmt_actualizar->execute();
        
        $mensaje = "Precio actualizado con éxito (fechas modificadas)";
    } else {
        // No existe un precio con estos datos → INSERTAR NUEVO PRECIO
        $PrecioData = [
            'id_prod' => $id_producto,
            'precio' => $_POST['precio'],
            'tipo' => $_POST['tipo'],
            'fecha_ini' => $fecha_Ini,
            'destino' => $PlantaV,
            'fecha_fin' => $fecha_Fin,
            'usuario' => $idUser,
            'status' => 1
        ];
        
        $columns = implode(', ', array_keys($PrecioData));
        $placeholders = str_repeat('?,', count($PrecioData) - 1) . '?';
        $sql = "INSERT INTO precios ($columns) VALUES ($placeholders)";
        $stmt = $conn_mysql->prepare($sql);
        $types = str_repeat('s', count($PrecioData));
        $stmt->bind_param($types, ...array_values($PrecioData));
        $stmt->execute();
        
        $mensaje = "Precio registrado con éxito";
    }

    alert($mensaje, 1, "V_producto&id=".$id_producto."");
    logActivity('PRECIO', $mensaje ." Para el producto ". $id_producto);
}
?>
<div class="container mt-2">
    <div class="card mb-4">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-0">Datos del producto</h5>
                <span class="small">Código: <?=$producto['cod']?></span>
            </div>
            <div class="d-flex gap-2">
                <a href="?p=productos" class="btn btn-sm rounded-3 btn-outline-light">
                    <i class="bi bi-arrow-left me-1"></i> Regresar
                </a>
                <a href="?p=E_producto&id=<?=$id_producto?>" class="btn btn-sm rounded-3 btn-light" <?= $perm['Clien_Editar'];?>>
                    <i class="bi bi-pencil me-1"></i> Editar
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 col-12 mb-4">
                    <div class="card">
                        <div class="card-header">
                            Información del producto <i class="bi bi-box-seam text-primary"></i>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Producto
                                    <span class="badge text-body"><?=$producto['nom_pro']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Codigo
                                    <span class="badge text-body"><?=$producto['cod']?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Linea
                                    <span class="badge text-body"><?=$producto['lin']?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span>Precios <i class="bi bi-cash-stack text-teal"></i></span>
                            <button <?= $perm['sub_precios'];?> type="button" class="btn btn-success btn-sm rounded-3" data-bs-toggle="modal" data-bs-target="#AgregarPrec">
                                <i class="bi bi-plus-circle me-1"></i> Agregar
                            </button>
                        </div>
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">Precios de compra</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead>
                                        <tr>
                                            <th>Precio</th>
                                            <th>Vigencia</th>
                                            <th width="80">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $PreciCom00 = $conn_mysql->query("SELECT * FROM precios where tipo = 'c' AND status = '1' AND id_prod = '$id_producto'");
                                        while ($PreciCom01 = mysqli_fetch_array($PreciCom00)) {
                                            ?>
                                            <tr>
                                                <td class="fw-semibold">$<?=number_format($PreciCom01['precio'], 2)?></td>
                                                <td>
                                                    <small class="text-muted">
                                                        De <?=date('Y-m-d', strtotime($PreciCom01['fecha_ini']))?> a <?=date('Y-m-d', strtotime($PreciCom01['fecha_fin']))?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <!-- Button trigger modal -->
                                                    <button <?= $perm['sub_precios'];?> type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminarPrecio" data-precio-id="<?=$PreciCom01['id_precio']?>" data-precio-valor="$<?=number_format($PreciCom01['precio'], 2)?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                        if(mysqli_num_rows($PreciCom00) == 0): ?>
                                            <tr>
                                                <td colspan="3" class="text-center text-muted py-3">No hay precios de compra registrados</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <hr class="my-3">

                            <h6 class="card-subtitle mb-2 text-muted">Precios de venta</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead>
                                        <tr>
                                            <th>Precio</th>
                                            <th>Cliente</th>
                                            <th>Vigencia</th>
                                            <th width="80">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $PreciVen00 = $conn_mysql->query("
                                            SELECT p.*, d.cod_al, d.noma 
                                            FROM precios p 
                                            LEFT JOIN direcciones d ON p.destino = d.id_direc 
                                            WHERE p.tipo = 'v' AND p.status = '1' AND p.id_prod = '$id_producto'
                                            ");
                                        while ($PreciVen01 = mysqli_fetch_array($PreciVen00)) {
                                            $cliente = "General";
                                            if ($PreciVen01['destino'] != '0' && $PreciVen01['destino'] != '') {
                                                $cliente = $PreciVen01['cod_al'] . " - " . $PreciVen01['noma'];
                                            }
                                            ?>
                                            <tr>
                                                <td class="fw-semibold">$<?=number_format($PreciVen01['precio'], 2)?></td>
                                                <td>
                                                    <small class="<?= $PreciVen01['destino'] != '0' ? 'text-primary fw-semibold' : 'text-muted' ?>">
                                                        <?= $cliente ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        De <?=date('Y-m-d', strtotime($PreciVen01['fecha_ini']))?> a <?=date('Y-m-d', strtotime($PreciVen01['fecha_fin']))?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <button <?= $perm['sub_precios'];?> type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modalEliminarPrecio" data-precio-id="<?=$PreciVen01['id_precio']?>" data-precio-valor="$<?=number_format($PreciVen01['precio'], 2)?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                        if(mysqli_num_rows($PreciVen00) == 0): ?>
                                            <tr>
                                                <td colspan="4" class="text-center text-muted py-3">No hay precios de venta registrados</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 

Modal para nuevo precio 
información principal

-->
<!-- Modal para nuevo precio -->
<div class="modal fade" id="AgregarPrec" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form class="forms-sample" method="post" action="" id="formPrecio">
                <div class="modal-header text-bg-success">
                    <h5 class="modal-title" id="exampleModalLabel">
                        <i class="bi bi-tag me-2"></i> Nuevo precio
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <label for="tipo" class="form-label">Tipo</label>
                            <select class="form-select" name="tipo" id="tipo" required>
                                <option value="c">Compra</option>
                                <option value="v">Venta</option>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <label for="precio" class="form-label">Precio $</label>
                            <input type="number" step="0.01" min="0" name="precio" id="precio" class="form-control" required>
                        </div>
                        <div class="col-sm-6">
                            <label for="fechaini" class="form-label">Fecha de Inicio</label>
                            <input type="date" value="<?= date('Y-m-01') ?>" name="fechaini" id="fechaini" class="form-control" required>
                        </div>
                        <div class="col-sm-6">
                            <label for="fechafin" class="form-label">Fecha Final</label>
                            <input type="date" value="<?= date('Y-m-d') ?>" name="fechafin" id="fechafin" class="form-control" required>
                        </div>
                        
                        <!-- Campo OBLIGATORIO para Ligar Cliente en ventas -->
                        <div class="col-12" id="contenedor-cliente" style="display: none;">
                            <label for="planta" class="form-label">Cliente <span class="text-danger">*</span></label>
                            <select class="form-select" name="planta" id="planta" required>
                                <option value="">Selecciona un cliente</option>
                                <?php
                                $BusC0 = $conn_mysql->query("SELECT * FROM direcciones WHERE status = '1' AND id_us is not null order by cod_al");
                                while ($BusC1 = mysqli_fetch_array($BusC0)) {
                                    ?>
                                    <option value="<?=$BusC1['id_direc']?>"><?=$BusC1['cod_al']." (".$BusC1['noma'].")"?></option>
                                    <?php
                                }
                                ?>
                            </select>
                            <div class="form-text text-danger">Para precios de venta es obligatorio seleccionar un cliente</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary rounded-3 btn-sm" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Cancelar
                    </button>
                    <button type="submit" name="guardar01" class="btn btn-success rounded-3 btn-sm">
                        <i class="bi bi-check-circle me-1"></i> Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tipoSelect = document.getElementById('tipo');
    const contenedorCliente = document.getElementById('contenedor-cliente');
    const plantaSelect = document.getElementById('planta');
    const formPrecio = document.getElementById('formPrecio');

    function toggleClienteField() {
        if (tipoSelect.value === 'v') {
            // Mostrar campo OBLIGATORIO para ventas
            contenedorCliente.style.display = 'block';
            plantaSelect.required = true;
            plantaSelect.disabled = false;
        } else {
            // Ocultar campo para compras
            contenedorCliente.style.display = 'none';
            plantaSelect.required = false;
            plantaSelect.disabled = true;
            plantaSelect.value = ''; // Limpiar valor
        }
    }

    // Ejecutar al cambiar y al cargar la página
    tipoSelect.addEventListener('change', toggleClienteField);
    toggleClienteField(); // Ejecutar al cargar

    // Validación personalizada del formulario
    formPrecio.addEventListener('submit', function(e) {
        if (tipoSelect.value === 'v' && (plantaSelect.value === '' || plantaSelect.value === '0')) {
            e.preventDefault();
            alert('Para precios de venta es obligatorio seleccionar un cliente.');
            plantaSelect.focus();
            return false;
        }
    });

    // Inicializar Select2
    $(document).ready(function() {
        $('#planta').select2({
            allowClear: false,
            language: "es",
            dropdownParent: $('#AgregarPrec'),
            width: '100%',
            placeholder: "Selecciona un cliente"
        });
    });
});
</script>

<!-- Modal único para eliminar precio -->
<div class="modal fade" id="modalEliminarPrecio" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form class="forms-sample" method="post" action="">
                <div class="modal-header text-bg-danger">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Eliminar precio</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>¿Estás seguro de eliminar el precio <span id="precio-valor" class="fw-bold"></span>?</p>
                    <input type="hidden" name="id_precio" id="id-precio-eliminar">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm rounded-3" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" name="eliminar_precio" class="btn btn-danger btn-sm rounded-3">Eliminar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Script para manejar el modal de eliminación
    document.addEventListener('DOMContentLoaded', function() {
        const modalEliminar = document.getElementById('modalEliminarPrecio');

        modalEliminar.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const precioId = button.getAttribute('data-precio-id');
            const precioValor = button.getAttribute('data-precio-valor');

            document.getElementById('id-precio-eliminar').value = precioId;
            document.getElementById('precio-valor').textContent = precioValor;
        });
    });
</script>