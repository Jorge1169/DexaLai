   <?php
   if (isset($_POST['guardar01'])) {
    try {
      $CodCliente = $_POST['cod'] ?? '';
      $ClienteData = [
        'nombre' => $_POST['nombre'] ?? '',
        'cod' => $_POST['cod'] ?? '',
        'rs' => $_POST['rs'] ?? '',
        'rfc' => $_POST['rfc'] ?? '',
        'tpersona' => $_POST['tpersona'] ?? '',
        'obs' => $_POST['obsP'] ?? '',
        'id_user' => $idUser,
        'zona' => $_POST['zona'] ?? $zona_seleccionada
      ];

        // Insertar cliente con MySQLi
      $columns = implode(', ', array_keys($ClienteData));
      $placeholders = str_repeat('?,', count($ClienteData) - 1) . '?';
      $sql = "INSERT INTO clientes ($columns) VALUES ($placeholders)";
      $stmt = $conn_mysql->prepare($sql);

        // Pasar los valores en el orden correcto
        $types = str_repeat('s', count($ClienteData)); // 's' para string
        $stmt->bind_param($types, ...array_values($ClienteData));
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Obtener ID del cliente recién insertado
          $sqlSelect = "SELECT id_cli FROM clientes WHERE nombre = ? AND cod = ? AND rfc = ?";
          $stmtSelect = $conn_mysql->prepare($sqlSelect);
          $stmtSelect->bind_param('sss', $_POST['nombre'], $_POST['cod'], $_POST['rfc']);
          $stmtSelect->execute();
          $result = $stmtSelect->get_result();
          $ClienN0 = $result->fetch_assoc();
          $idCliente = $ClienN0['id_cli'];

            // Insertar dirección
          $DireccionData = [
            'cod_al' => $_POST['cod_al'] ?? '',
            'noma' => $_POST['noma'] ?? '',
            'atencion' => $_POST['atencion'] ?? '',
            'tel' => $_POST['tel'] ?? '',
            'email' => $_POST['email'] ?? '',
            'obs' => $_POST['obsD'] ?? '',
            'id_us' => $idCliente
          ];

          $columnsD = implode(', ', array_keys($DireccionData));
          $placeholdersD = str_repeat('?,', count($DireccionData) - 1) . '?';
          $sqlD = "INSERT INTO direcciones ($columnsD) VALUES ($placeholdersD)";
          $stmtD = $conn_mysql->prepare($sqlD);

          $typesD = str_repeat('s', count($DireccionData));
          $stmtD->bind_param($typesD, ...array_values($DireccionData));
          $stmtD->execute();

          if ($stmtD->affected_rows > 0) {
            alert("Cliente $CodCliente registrado exitosamente", 1, "V_cliente&id=$idCliente");
            logActivity('CREAR', 'Dio de alta un nuevo cliente '. $idCliente);
          } else {
            alert("Error al registrar la dirección", 0, "N_cliente");
          }
        } else {
          alert("Error al registrar el cliente", 0, "N_cliente");
        }
      } catch (mysqli_sql_exception $e) {
        alert("Error: " . $e->getMessage(), 0, "N_cliente");
      }
    }
    ?>
    <div class="container mt-2">
      <div class="card shadow-sm">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
          <h5 class="mb-0">Nuevo Cliente</h5>
          <a href="?p=clientes">
            <button type="button" class="btn btn-sm btn-danger">Cancelar</button>
          </a>
        </div>
        <div class="card-body">
          <form class="forms-sample" method="post" action="">
            <!-- Sección de información básica -->
            <div class="form-section">
              <h5 class="section-header">Información Básica</h5>
              <div class="row g-3">
                <div class="col-md-4">
                  <label for="codigo" class="form-label">Código <span id="resulpostal00"></span></label>
                  <input name="cod" type="text" class="form-control" id="codigo" oninput="codigo1()" required>
                </div>
                <div class="col-md-4">
                  <label for="razonSocial" class="form-label">Razón Social</label>
                  <input name="rs" type="text" class="form-control" id="razonSocial" required>
                </div>
                <div class="col-md-4">
                  <label for="nombre" class="form-label">Nombre</label>
                  <input name="nombre" type="text" class="form-control" id="nombre" required>
                </div>
                <div class="col-md-4">
                  <label for="rfc" class="form-label">RFC</label>
                  <input name="rfc" type="text" class="form-control" id="rfc">
                </div>
              <!-- 
              <div class="col-md-4">
                <label for="cuentaContable" class="form-label">Cuenta Contable</label>
                <input name="c_contable" type="text" class="form-control" id="cuentaContable">
              </div>
                -->
                <div class="col-md-4">
                  <label for="tipoPersona" class="form-label">Tipo de Persona</label>
                  <select class="form-select" name="tpersona" id="tipoPersona">
                    <option selected disabled>Seleccionar...</option>
                    <option value="fisica">Física</option>
                    <option value="moral">Moral</option>
                  </select>
                </div>
                <?php
            if ($zona_seleccionada == '0') {
              ?>
              <div class="col-md-4">
                <label for="zona" class="form-label">Zona</label>
                <select class="form-select" name="zona" id="zona">
                  <?php
                  $zona0 = $conn_mysql->query("SELECT * FROM zonas WHERE status = 1");
                  while ($zona1 = mysqli_fetch_array($zona0)) {
                    ?>
                    <option value="<?=$zona1['id_zone']?>" <?= ($zona_seleccionada ?? '') == $zona1['id_zone'] ? 'selected' : '' ?>> <?=$zona1['nom']?> </option>
                    <?php
                  }
                  ?>
                </select>
              </div>
              <?php
            }
            ?>
              </div>
            </div>

            <!-- Sección de almacén -->
            <div class="form-section">
              <h5 class="section-header">Bodega</h5>
              <div class="row g-3">
                <div class="col-md-6">
                  <label for="codigoAlmacen" class="form-label">Código de Bodega</label>
                  <input name="cod_al" type="text" class="form-control" id="codigoAlmacen">
                </div>
                <div class="col-md-6">
                  <label for="nombreAlmacen" class="form-label">Nombre de Bodega</label>
                  <input name="noma" type="text" class="form-control" id="nombreAlmacen">
                </div>
              </div>
            </div>

            <!-- Sección de dirección -->
            <div class="form-section">
              <h5 class="section-header">Información de Bodega</h5>
              <div class="row g-3">
                <div class="col-md-6">
                  <label for="atencion" class="form-label">Atención</label>
                  <input name="atencion" type="text" class="form-control" id="atencion" value="N/S">
                </div>
                <div class="col-md-3">
                  <label for="telefono" class="form-label">Teléfono</label>
                  <input name="tel" type="tel" class="form-control" id="telefono" value="55 5555 5555">
                </div>
                <div class="col-md-3">
                  <label for="email" class="form-label">Email</label>
                  <input name="email" type="email" class="form-control" id="email">
                </div>
              <!--
              <div class="col-md-2">
                <label for="pais" class="form-label">País</label>
                <select class="form-select" name="pais" id="pais" required>
                  <option value="mexico">México</option>
                </select>
              </div>
              <div class="col-md-2">
                <label for="calle" class="form-label">Codigo Postal</label>
                <input name="c_postal" type="text" class="form-control" id="Cpostal" required>
              </div>
              <div class="col-md-4">
                <label for="calle" class="form-label">Calle</label>
                <input name="calle" type="text" class="form-control" id="calle" required>
              </div>
              <div class="col-md-2">
                <label for="numeroExterior" class="form-label">Número Exterior</label>
                <input name="numext" type="text" class="form-control" id="numeroExterior" required>
              </div>
              <div class="col-md-2">
                <label for="numeroInterior" class="form-label">Número Interior</label>
                <input name="numint" type="text" class="form-control" id="numeroInterior">
              </div>
              <div class="col-md-4">
                <label for="estado" class="form-label">Estado</label>
                <input name="estado" type="text" class="form-control" id="estado" required>
              </div>
              <div class="col-md-4">
                <label for="municipio" class="form-label">Municipio</label>
                <input name="mun" type="text" class="form-control" id="municipio" required>
              </div>
              <div class="col-md-4">
                <label for="colonia" class="form-label">Colonia</label>
                <input name="colonia" type="text" class="form-control" id="colonia" required>
              </div>
                -->
                <div class="col-md-6">
                  <label for="observaciones" class="form-label">Observaciones</label>
                  <textarea class="form-control" name="obsD" id="observaciones" rows="3"></textarea>
                </div>
              </div>
            </div>

          <!-- Sección de información fiscal y pagos 
          <div class="form-section">
            <h5 class="section-header">Información Fiscal y Pagos</h5>
            <div class="row g-3">
              <div class="col-md-3">
                <label for="metodoPago" class="form-label">Método de Pago</label>
                <select class="form-select" name="m_pago" id="metodoPago">
                  <option selected disabled>Seleccionar...</option>
                  <option value="pue">PUE - Pago en una sola exhibición</option>
                  <option value="ppd">PPD - Pago en parcialidades</option>
                </select>
              </div>
              <div class="col-md-3">
                <label for="formaPago" class="form-label">Forma de Pago</label>
                <select class="form-select" name="f_pago" id="formaPago">
                  <option selected disabled>Seleccionar...</option>
                  <option value="01">01 - Efectivo</option>
                  <option value="02">02 - Cheque nominativo</option>
                  <option value="03">03 - Transferencia</option>
                  <option value="04">04 - Tarjeta de credito</option>
                  <option value="99">99 - Por definir</option>
                  <option value="NA">NA - No aplica</option>
                </select>
              </div>
              <div class="col-md-6">
                <label for="dirigidoA" class="form-label">Dirigido A</label>
                <input name="dir_a" type="text" class="form-control" id="dirigidoA">
              </div>
              <div class="col-md-3">
                <label for="banco" class="form-label">Banco</label>
                <select class="form-select" name="banco" id="banco">
                  <option selected disabled>Seleccionar...</option>
                  <option value="001">Banamex</option>
                  <option value="010">BanBajio</option>
                  <option value="004">Banco Azteca</option>
                  <option value="002">Bancomer</option>
                  <option value="003">Bancoppel</option>
                  <option value="005">Banjercito</option>
                  <option value="007">Banorte</option>
                  <option value="006">HSBC</option>
                  <option value="008">No Especifica</option>
                  <option value="009">Santander</option>
                  <option value="011">Scotiabank</option>
                </select>
              </div>
              <div class="col-md-3">
                <label for="noCuenta" class="form-label">No. de Cuenta</label>
                <input name="nom_cuenta" type="text" class="form-control" id="noCuenta">
              </div>
              <div class="col-md-3">
                <label for="usoCFDI" class="form-label">Uso del CFDI</label>
                <select class="form-select" name="cfdi" id="usoCFDI">
                  <option selected disabled>Seleccionar...</option>
                  <option value="G01">G01 - Adquisición de mercancías</option>
                  <option value="G03">G03 - Gastos en general</option>
                  <option value="P01">P01 - Por definir</option>
                </select>
              </div>
              <div class="col-md-3">
                <label for="condicionesPago" class="form-label">Condiciones de Pago</label>
                <select class="form-select" name="con_pago" id="condicionesPago">
                  <option selected disabled>Seleccionar...</option>
                  <option value="100 DIAS*0">100 DIAS   </option>
                  <option value="15 DIAS*0">15 DIAS   </option>
                  <option value="20 DIAS*0">20 DIAS   </option>
                  <option value="25 DIAS*0">25 DIAS   </option>
                  <option value="30 DIAS*0">30 DIAS   </option>
                  <option value="45 DIAS*0">45 DIAS   </option>
                  <option value="50 DIAS*0">50 DIAS   </option>
                  <option value="50% Anticipo*0">50% Anticipo   </option>
                  <option value="50% Anticipo*30">50% Anticipo 30 Dias</option>
                  <option value="50% Anticipo*8">50% Anticipo 8 Dias</option>
                  <option value="60 DIAS*0">60 DIAS   </option>
                  <option value="73 DIAS*0">73 DIAS   </option>
                  <option value="8 DIAS*0">8 DIAS   </option>
                  <option value="80 DIAS*0">80 DIAS   </option>
                  <option value="85 DIAS*0">85 DIAS   </option>
                  <option value="90 DIAS*0">90 DIAS   </option>
                  <option value="A Credito*0">A Credito  Dias</option>
                  <option value="A Credito*1">A Credito 1 Dia</option>
                  <option value="A Credito*15">A Credito 15 Dias</option>
                  <option value="A Credito*2">A Credito 2 Dias</option>
                  <option value="A Credito*3">A Credito 3 Dias</option>
                  <option value="A Credito*30">A Credito 30 Dias</option>
                  <option value="A Credito*4">A Credito 4 Dias</option>
                  <option value="A Credito*45">A Credito 45 Dias</option>
                  <option value="A Credito*5">A Credito 5 Dias</option>
                  <option value="A Credito*6">A Credito 6 Dias</option>
                  <option value="A Credito*60">A Credito 60 Dias</option>
                  <option value="A Credito*7">A Credito 7 Dias</option>
                  <option value="A Credito*8">A Credito 8 Dias</option>
                  <option value="A Credito*9">A Credito 9 Dias</option>
                  <option value="A Credito*90">A Credito 90 Dias</option>
                  <option value="ANTICIPO*0">ANTICIPO   </option>
                  <option value="ANTICIPO 100%*0">ANTICIPO 100%   </option>
                  <option value="ANTICIPO 50%*0">ANTICIPO 50%   </option>
                  <option value="C.O.D*0">C.O.D   </option>
                  <option value="C.O.O.*0">C.O.O.   </option>
                  <option value="Cheque vs Entrega*0">Cheque vs Entrega   </option>
                  <option value="Cheque vs Entrega*15">Cheque vs Entrega 15 Dias</option>
                  <option value="Cheque vs Entrega*30">Cheque vs Entrega 30 Dias</option>
                  <option value="Cheque vs Entrega*8">Cheque vs Entrega 8 Dias</option>
                  <option value="CONTRA ENTREGA*0">CONTRA ENTREGA   </option>
                  <option value="Fechado Cheque Post*0">Fechado Cheque Post   </option>
                  <option value="Fechado Cheque Post*15">Fechado Cheque Post 15 Dias</option>
                  <option value="Fechado Cheque Post*30">Fechado Cheque Post 30 Dias</option>
                  <option value="Fechado Cheque Post*45">Fechado Cheque Post 45 Dias</option>
                  <option value="Prepagado*0">Prepagado   </option>
                  <option value="Prepagado*30">Prepagado 30 Dias</option>
                  <option value="Prepagado*8">Prepagado 8 Dias</option>
                  <option value="Sin Definir*0">Sin Definir   </option>
                </select>
              </div>
            </div>
          </div>
            -->

            <!-- Sección de observaciones -->
            <div class="form-section">
              <h5 class="section-header">Observaciones</h5>
              <div class="mb-3">
                <label for="observaciones" class="form-label">Observaciones</label>
                <textarea class="form-control" name="obsP" id="observaciones" rows="3"></textarea>
              </div>
            </div>

            <!-- Botones de acción -->
            <div class="d-flex justify-content-md-end mt-4">
              <button type="submit" name="guardar01" class="btn btn-primary">Guardar</button>
            </div>
            <script>
              $(document).ready(function() {
                let bodegaEditada = {
                  codigo: false,
                  nombre: false
                };

  // Detectar edición manual de bodegas
                $('#codigoAlmacen').on('input', function() {
                  bodegaEditada.codigo = true;
                });
                
                $('#nombreAlmacen').on('input', function() {
                  bodegaEditada.nombre = true;
                });

  // Actualizar bodegas cuando cambian los datos del cliente
                $('#codigo, #razonSocial').on('input', function() {
                  if(!bodegaEditada.codigo) {
                    $('#codigoAlmacen').val($('#codigo').val());
                  }
                  if(!bodegaEditada.nombre) {
                    $('#nombreAlmacen').val($('#razonSocial').val());
                  }
                });
                
  // Actualizar al enviar el formulario
                $('form').on('submit', function() {
                  if(!bodegaEditada.codigo) {
                    $('#codigoAlmacen').val($('#codigo').val());
                  }
                  if(!bodegaEditada.nombre) {
                    $('#nombreAlmacen').val($('#razonSocial').val());
                  }
                  return true;
                });
                
  // Inicializar valores al cargar
                $('#codigoAlmacen').val($('#codigo').val());
                $('#nombreAlmacen').val($('#razonSocial').val());
              });
            </script>
          </form>
        </div>
      </div>
    </div>
    <script>
      function codigo1() {
        var codigo = document.getElementById('codigo').value;

        var parametros = {
          "codigo_CLIENTE": codigo,
        };

        console.log(parametros);

        $.ajax({
          data: parametros,
          url: 'cd_php.php',
          type: 'POST',
          beforeSend: function () {
            $('#resulpostal00').html("");
          },
          success: function (mensaje) {
            $('#resulpostal00').html(mensaje);
          }
        });
      }
    </script>