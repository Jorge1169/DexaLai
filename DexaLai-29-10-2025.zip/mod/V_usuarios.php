<style>
    /* Estilos para SweetAlert2 en modo oscuro */
[data-bs-theme="dark"] .swal2-popup {
    background: #1f2937 !important;
    color: #e5e7eb !important;
}

[data-bs-theme="dark"] .swal2-title {
    color: #f9fafb !important;
}

[data-bs-theme="dark"] .swal2-html-container {
    color: #e5e7eb !important;
}

[data-bs-theme="dark"] .swal2-confirm {
    background-color: #6f42c1 !important;
    border-color: #6f42c1 !important;
}

[data-bs-theme="dark"] .swal2-cancel {
    background-color: #6c757d !important;
    border-color: #6c757d !important;
    color: white !important;
}
</style>
<?php

// Obtener ID del usuario a visualizar
$id_usuario = $_GET['id'] ?? 0;
$zona_user = '';
// Consultar datos del usuario
$usuarioQuery = $conn_mysql->prepare("SELECT * FROM usuarios WHERE id_user = ?");
$usuarioQuery->bind_param('i', $id_usuario);
$usuarioQuery->execute();
$usuarioData = $usuarioQuery->get_result()->fetch_assoc();

if (!$usuarioData) {
    alert("Usuario no encontrado", 0, "usuarios");
    exit();
}
if ($usuarioData['zona'] == 0) {
    $zona_user = 'Todas';
}else{
    $zon0 = $conn_mysql->query("SELECT * from zonas WHERE id_zone = '".$usuarioData['zona']."'");
    $zon1 = mysqli_fetch_array($zon0);
    $zona_user = $zon1['nom'];
}
// Determinar tipo de usuario
$tipoUsuario = '';
$badgeClass = '';
switch($usuarioData['tipo']) {
    case 100:
    $tipoUsuario = 'Administrador';
    $badgeClass = 'bg-danger';
    break;
    case 50:
    $tipoUsuario = 'Usuario A';
    $badgeClass = 'bg-primary';
    break;
    case 30:
    $tipoUsuario = 'Usuario B';
    $badgeClass = 'bg-info';
    break;
    case 10:
    $tipoUsuario = 'Usuario C';
    $badgeClass = 'bg-secondary';
    break;
    default:
    $tipoUsuario = 'Desconocido';
    $badgeClass = 'bg-warning text-dark';
}
// Formatear fecha de registro
?>

<div class="container mt-2">
    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-semibold">Información del Usuario</h5>
            <div class="d-flex gap-2">
                <a <?= $perm['INACTIVO']; ?> href="?p=usuarios" class="btn btn-sm rounded-3 btn-outline-light">
                    <i class="bi bi-arrow-left me-1"></i> Volver
                </a>
                <a <?= $perm['INACTIVO']; ?> href="?p=E_usuario&id=<?= $id_usuario ?>" class="btn btn-sm rounded-3 btn-light">
                    <i class="bi bi-pencil me-1"></i> Editar
                </a>    
                <!-- Botón de Iniciar Sesión Como (Solo para admins y no para sí mismo) -->
                <?php if ($TipoUserSession == 100 && $id_usuario != $idUser && $usuarioData['status'] == 1): ?>
                    <button type="button" class="btn btn-sm rounded-3 btn-warning" 
                    onclick="confirmSudoLogin(<?= $id_usuario ?>, '<?= htmlspecialchars($usuarioData['nombre']) ?>')">
                    <i class="bi bi-person-check me-1"></i> Iniciar Sesión Como
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body p-4">
        <!-- Perfil del usuario -->
        <div class="row align-items-center mb-4 pb-3 border-bottom">
            <div class="d-flex align-items-center">
                <div class="avatar-container me-3">
                    <div class="avatar bg-primary text-white">
                        <?= strtoupper(substr($usuarioData['nombre'], 0, 1)) ?>
                    </div>
                </div>
                <div>
                    <h3 class="mb-1 fw-bold"><?= htmlspecialchars($usuarioData['nombre']) ?></h3>
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <span class="badge <?= $badgeClass ?>"><?= $tipoUsuario ?></span>
                        <span class="badge <?= ($usuarioData['status'] == 1) ? 'bg-success' : 'bg-danger' ?>">
                            <?= ($usuarioData['status'] == 1) ? 'Activo' : 'Inactivo' ?>
                        </span>
                        <span class="text-muted small">
                            <i class="bi bi-calendar me-1"></i> Registro: <?= date('d/m/Y', strtotime($usuarioData['fecha'])) ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Información general -->
        <div class="row g-4">
            <!-- Columna izquierda -->
            <div class="col-lg-5 mb-4 mb-lg-0">
                <div class="card h-100 border-1 ">
                    <div class="card-body">
                        <h5 class="card-title mb-4 d-flex align-items-center">
                            <i class="bi bi-info-circle-fill text-primary me-2"></i>
                            Información Básica
                        </h5>

                        <div class="info-item mb-3">
                            <div class="info-label small text-muted">Usuario</div>
                            <div class="info-value fw-medium"><?= htmlspecialchars($usuarioData['usuario']) ?></div>
                        </div>

                        <div class="info-item mb-3">
                            <div class="info-label small text-muted">Correo electrónico</div>
                            <div class="info-value fw-medium"><?= htmlspecialchars($usuarioData['correo']) ?></div>
                        </div>

                        <div class="info-item">
                            <div class="info-label small text-muted">Zona asignada</div>
                            <div class="info-value fw-medium"><?= $zona_user ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Columna derecha -->
            <div class="col-lg-7">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <h5 class="card-title mb-4 d-flex align-items-center">
                            <i class="bi bi-shield-lock text-primary me-2"></i>
                            Permisos del Sistema
                        </h5>

                        <!-- Resumen de permisos -->
                        <div class="row mb-4">
                            <div class="col-md-6 mb-3 mb-md-0">
                                <div class="p-3 border border-1 rounded-3 h-100">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="fw-medium">Creación</span>
                                        <span class="badge bg-primary rounded-pill">
                                            <?= array_sum([$usuarioData['a'], $usuarioData['b'], $usuarioData['c'], $usuarioData['d'], $usuarioData['e']]) ?>/5
                                        </span>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-primary" role="progressbar" 
                                        style="width: <?= (array_sum([$usuarioData['a'], $usuarioData['b'], $usuarioData['c'], $usuarioData['d'], $usuarioData['e']])/5)*100 ?>%">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="p-3 border border-1 rounded-3 h-100">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fw-medium">Edición</span>
                                    <span class="badge bg-primary rounded-pill">
                                        <?= array_sum([$usuarioData['a1'], $usuarioData['b1'], $usuarioData['c1'], $usuarioData['d1'], $usuarioData['e1']]) ?>/5
                                    </span>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-primary" role="progressbar" 
                                    style="width: <?= (array_sum([$usuarioData['a1'], $usuarioData['b1'], $usuarioData['c1'], $usuarioData['d1'], $usuarioData['e1']])/5)*100 ?>%">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Detalle de permisos -->
                <div class="row g-3">
                    <?php 
                    $permisos = [
                        'a' => 'Proveedores', 
                        'b' => 'Clientes', 
                        'c' => 'Productos', 
                        'd' => 'Almacenes', 
                        'e' => 'Transportistas',
                        'f' => 'Recolección'
                    ];
                    foreach ($permisos as $key => $label): ?>
                        <div class="col-6 col-md-4">
                            <div class="p-3 border border-1 rounded-3 h-100">
                                <div class="fw-medium mb-2 small"><?= $label ?></div>
                                <div class="d-flex flex-wrap gap-2">
                                    <span class="badge <?= ($usuarioData[$key] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                        <i class="bi bi-plus-circle me-1"></i>Crear
                                    </span>
                                    <span class="badge <?= ($usuarioData[$key.'1'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                        <i class="bi bi-pencil-square me-1"></i>Editar
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div class="col-6 col-md-4">
                        <div class="p-3 border border-1 rounded-3 h-100">
                            <div class="fw-medium mb-2 small">Actualizar</div>
                            <span class="badge <?= ($usuarioData['af'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <i class="bi bi-arrow-repeat me-1"></i>Facturas
                            </span>
                            <span class="badge <?= ($usuarioData['acr'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <i class="bi bi-arrow-repeat me-1"></i>Contra R.
                            </span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="p-3 border border-1 rounded-3 h-100">
                            <div class="fw-medium mb-2 small">Administrativos</div>
                            <span class="badge <?= ($usuarioData['acc'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <?= ($usuarioData['acc'] == 1) ? '<i class="bi bi-check-circle"></i>' : '<i class="bi bi-x-circle"></i>'?> Autorizar
                            </span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="p-3 border border-1 rounded-3 h-100">
                            <div class="fw-medium mb-2 small">Enviar correos</div>
                            <span class="badge <?= ($usuarioData['en_correo'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <?= ($usuarioData['en_correo'] == 1) ? '<i class="bi bi-check-circle"></i>' : '<i class="bi bi-x-circle"></i>'?> Enviar
                            </span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="p-3 border border-1 rounded-3 h-100">
                            <div class="fw-medium mb-2 small">Dar de alta precios</div>
                            <span class="badge <?= ($usuarioData['prec'] == 1) ? 'bg-success' : 'bg-secondary' ?> rounded-pill">
                                <?= ($usuarioData['prec'] == 1) ? '<i class="bi bi-check-circle"></i>' : '<i class="bi bi-x-circle"></i>'?> Precio
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

</div> 
<script>
function confirmSudoLogin(userId, userName) {
    Swal.fire({
        title: '¿Iniciar sesión como otro usuario?',
        html: `Estás a punto de iniciar sesión como:<br><strong>${userName}</strong><br><br>
              <div class="alert alert-warning small">
                  <i class="bi bi-exclamation-triangle"></i> 
                  <strong>Importante:</strong> 
                  - Esta acción quedará registrada en el sistema<br>
                  - Podrás regresar a tu sesión original en cualquier momento
              </div>`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ffc107',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="bi bi-person-check me-1"></i> Sí, iniciar sesión',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            // Crear formulario para enviar por POST
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '?p=sudo_login';
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'target_user';
            input.value = userId;
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    });
}
</script>
</div>


<style>


/* Avatar */
.avatar-container {
    position: relative;
}

.avatar {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    font-weight: bold;
}

/* Elementos de información */
.info-item {
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
}

.info-item:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.info-label {
    margin-bottom: 4px;
}

.info-value {
    font-size: 16px;
}

/* Badges */
.badge {
    font-weight: 500;
    padding: 5px 10px;
}

/* Títulos */
.card-title {
    font-size: 18px;
}

/* Responsive */
@media (max-width: 768px) {
    .avatar {
        width: 60px;
        height: 60px;
        font-size: 24px;
    }

    .info-value {
        font-size: 15px;
    }
}
</style>