<?php
session_start();
require_once 'config/conexiones.php';

// Verificar si el usuario tiene permiso para cambiar de zona
if (!isset($_SESSION['id_cliente'])) {
    header('Location: ?p=inicio');
    exit();
}

// Obtener datos del usuario
$user_query = mysqli_query($conn_mysql, "SELECT zona FROM usuarios WHERE id_user = '".$_SESSION['id_cliente']."'");
$user_data = mysqli_fetch_assoc($user_query);
$zona_user = $user_data['zona'];

// Si el usuario está restringido a una zona específica, no permitir cambiar
if ($zona_user != 0) {
    $_SESSION['selected_zone'] = $zona_user;
    $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '?p=inicio';
    header('Location: ' . $redirect_url);
    exit();
}

// Procesar cambio de zona solo si el usuario tiene permiso (zona_user = 0)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_zone'])) {
    $selected_zone = mysqli_real_escape_string($conn_mysql, $_POST['selected_zone']);
    
    // Validar que la zona seleccionada exista
    if ($selected_zone === '0') {
        $_SESSION['selected_zone'] = '0';
    } else {
        $query = "SELECT id_zone FROM zonas WHERE id_zone = '$selected_zone' AND status = 1";
        $result = mysqli_query($conn_mysql, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $_SESSION['selected_zone'] = $selected_zone;
        } else {
            $_SESSION['selected_zone'] = '0';
        }
        
        if ($result) mysqli_free_result($result);
    }
}

// Redirigir de vuelta
$redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '?p=inicio';
header('Location: ' . $redirect_url);
exit();
?>