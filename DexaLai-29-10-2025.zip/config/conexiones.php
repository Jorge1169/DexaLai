<?php 
@session_start();
@extract($_REQUEST);
/*******************************
 * CONEXIONES A MYSQL
 *******************************/
$conn_mysql_R = '0'; //Resultados de conexion exitosa 1 no exitosa 0
// 4. Conexión principal a MySQL (Pruebas)
$mysql_host = "localhost";
$mysql_user = "root";
$mysql_pass = "";
$mysql_dbname = "dexa_lai";

try {
// Conexión MySQL con mysqli
    $conn_mysql = mysqli_connect($mysql_host, $mysql_user, $mysql_pass, $mysql_dbname);
    $conn_mysql_R = '1'; // conexion exitosa
} catch (Exception $e) {
 die("Error en conexión a MySQL: " . mysqli_connect_error() . "<br>");
    $conn_mysql_R = '0'; // conexion xon error
}


// Función para conexión MySQL con configuración de caracteres
function getMysqlConnection() {
    global $mysql_host, $mysql_user, $mysql_pass, $mysql_dbname;
    
    $connection = mysqli_connect($mysql_host, $mysql_user, $mysql_pass, $mysql_dbname);
    
    if (!$connection) {
        die("Error en conexión a la base de datos: " . mysqli_connect_error());
        $conn_mysql_R = '0'; // conexion xon error
    }
    
    // Establecer codificación de caracteres
    $connection->set_charset("utf8mb4");
    
    return $connection;
}
// Función para limpiar datos para prevenir inyección SQL y XSS
function clear($var)
{
    return htmlspecialchars($var);
}

// Función para verificar si el usuario es un administrador
function check_admin()
{
    if (!isset($_SESSION['id'])) {
        redir("./");
    }
}

// Función para redireccionar
function redir($var)
{
    echo "<script>window.location = '$var';</script>";
    die();
}

// Función para mostrar alertas
function alert($txt, $type, $url) {
    // "error", "success" and "info".
    $t = ($type == 0) ? "error" : (($type == 1) ? "success" : "info");
    
    echo "<script>
    // Función para leer cookies
    function getCookie(name) {
        const value = `; \${document.cookie}`;
        const parts = value.split(`; \${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return 'light'; // Tema predeterminado si no hay cookie
    }
    
    const currentTheme = getCookie('theme') || 'light';
    
    Swal.fire({
        title: 'Alerta',
        text: '".addslashes($txt)."',
        icon: '$t',
        allowOutsideClick: false,
        allowEscapeKey: false,
        allowEnterKey: false,
        showConfirmButton: true,
        confirmButtonText: 'Aceptar',
        // Configuración dinámica del tema
        theme: currentTheme,
        // Personalización de colores según el tema
        color: currentTheme === 'dark' ? '#ffffff' : '#212529',
        background: currentTheme === 'dark' ? '#111827' : '#ffffff',

        confirmButtonColor: currentTheme === 'dark' ? '#6f42c1' : '#0d6efd'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location='?p=".$url."';
            }
            });
            </script>";
        }
        function permisos($tipo, $permi) {
            $permiso = explode(",", $permi);
            $Admin = '';
            $DesAct = '';
            $Inactivos = '';
            $Reportes = '';
            $utilerias = '';
            if ($tipo == 100) {
                $Admin = '';
                $DesAct = '';
                $Inactivos = '';
                $Reportes = '';
                $utilerias = '';
            }
            elseif ($tipo == 50) {
                $Admin = 'style="display: none"';
                $DesAct = '';
                $Inactivos = 'style="display: none"';
                $Reportes = '';
                $utilerias = 'style="display: none"';
            }elseif ($tipo == 30) {
                $Admin = 'style="display: none"';
                $DesAct = 'style="display: none"';
                $Inactivos = 'style="display: none"';
                $Reportes = '';
                $utilerias = 'style="display: none"';
            }else {
                $Admin = 'style="display: none"';
                $DesAct = 'style="display: none"';
                $Inactivos = 'style="display: none"';
                $Reportes = 'style="display: none"';
                $utilerias = 'style="display: none"';
            }

            return [
                'Prove_Crear'  => ($permiso[0] == '1') ? "" : 'style="display: none"',//a
                'Clien_Crear'  => ($permiso[1] == '1') ? "" : 'style="display: none"',//b
                'Produ_Crear'  => ($permiso[2] == '1') ? "" : 'style="display: none"',//c
                'Almac_Crear'  => ($permiso[3] == '1') ? "" : 'style="display: none"',//d
                'Trans_Crear'  => ($permiso[4] == '1') ? "" : 'style="display: none"',//e
                'Prove_Editar' => ($permiso[5] == '1') ? "" : 'style="display: none"',//a1
                'Clien_Editar' => ($permiso[6] == '1') ? "" : 'style="display: none"',//b1
                'Produ_Editar' => ($permiso[7] == '1') ? "" : 'style="display: none"',//c1
                'Almac_Editar' => ($permiso[8] == '1') ? "" : 'style="display: none"',//d1
                'Trans_Editar' => ($permiso[9] == '1') ? "" : 'style="display: none"',//e1
                'ACT_FAC' => ($permiso[10] == '1') ? "" : 'style="display: none"',//af
                'ACT_CR' => ($permiso[11] == '1') ? "" : 'style="display: none"',//acr
                'ACT_AC' => ($permiso[12] == '1') ? "" : 'style="display: none"',//acc
                'Recole_Crear' => ($permiso[13] == '1') ? "" : 'style="display: none"',//f
                'Recole_Editar' => ($permiso[14] == '1') ? "" : 'style="display: none"',//f1
                'en_correo' => ($permiso[15] == '1') ? "" : 'style="display: none"',//en_correo
                'sub_precios' => ($permiso[16] == '1') ? "" : 'style="display: none"',//prec

                'ACT_DES' => $DesAct,
                'ADMIN' => $Admin,
                'INACTIVO' => $Inactivos,
                'REPORTES' => $Reportes,
                'UTILERIAS' => $utilerias

            ];
        }

// funcion para convertir fechas
        function convertirFecha($fecha) {
            $fecha = trim($fecha);
            
            if (empty($fecha)) {
                return '0000-00-00';
            }
            
            try {
                $date = DateTime::createFromFormat('d/m/Y', $fecha);
                if ($date === false) {
                    return '0000-00-00';
                }
                return $date->format('Y-m-d');
            } catch (Exception $e) {
                return '0000-00-00';
            }
        }


         $invoiceLK = "http://globaltycloud.com.mx:81/invoice/"; /// link de invoice
         $link = "http://localhost/DexaLai/doc/contra_recibos.php?id=";


 // ============================================================================
// FUNCIÓN PARA REGISTRAR ACTIVIDADES - AGREGAR ESTA NUEVA FUNCIÓN
// ============================================================================
function logActivity($action, $description = '') {
    global $conn_mysql;
    
    $user_id = $_SESSION['id_cliente'] ?? 0;
    $username = $_SESSION['username'] ?? 'Invitado';
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    // Limpiar los datos para prevenir inyección SQL
    $user_id = mysqli_real_escape_string($conn_mysql, $user_id);
    $username = mysqli_real_escape_string($conn_mysql, $username);
    $action = mysqli_real_escape_string($conn_mysql, $action);
    $description = mysqli_real_escape_string($conn_mysql, $description);
    $ip_address = mysqli_real_escape_string($conn_mysql, $ip_address);
    $user_agent = mysqli_real_escape_string($conn_mysql, $user_agent);
    
    $sql = "INSERT INTO user_activity_logs (user_id, username, action, description, ip_address, user_agent) 
            VALUES ('$user_id', '$username', '$action', '$description', '$ip_address', '$user_agent')";
    
    return mysqli_query($conn_mysql, $sql);
}

// ============================================================================
// FUNCIÓN PARA OBTENER LOGS (PARA REPORTES) - AGREGAR ESTA NUEVA FUNCIÓN
// ============================================================================
function getActivityLogs($filters = []) {
    global $conn_mysql;
    
    $sql = "SELECT * FROM user_activity_logs WHERE 1=1";
    
    // Aplicar filtros
    if (!empty($filters['user_id'])) {
        $user_id = mysqli_real_escape_string($conn_mysql, $filters['user_id']);
        $sql .= " AND user_id = '$user_id'";
    }
    
    if (!empty($filters['start_date'])) {
        $start_date = mysqli_real_escape_string($conn_mysql, $filters['start_date']);
        $sql .= " AND DATE(created_at) >= '$start_date'";
    }
    
    if (!empty($filters['end_date'])) {
        $end_date = mysqli_real_escape_string($conn_mysql, $filters['end_date']);
        $sql .= " AND DATE(created_at) <= '$end_date'";
    }
    
    if (!empty($filters['action'])) {
        $action = mysqli_real_escape_string($conn_mysql, $filters['action']);
        $sql .= " AND action LIKE '%$action%'";
    }
    
    if (!empty($filters['username'])) {
        $username = mysqli_real_escape_string($conn_mysql, $filters['username']);
        $sql .= " AND username LIKE '%$username%'";
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    // Limitar resultados si se especifica
    if (!empty($filters['limit'])) {
        $limit = intval($filters['limit']);
        $sql .= " LIMIT $limit";
    }
    
    $result = mysqli_query($conn_mysql, $sql);
    $logs = [];
    
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $logs[] = $row;
        }
    }
    
    return $logs;
}

// ============================================================================
// FUNCIÓN PARA INICIAR SESIÓN COMO OTRO USUARIO (SUDO)
// ============================================================================
function sudoLogin($target_user_id) {
    global $conn_mysql;

    
    // Obtener datos del usuario objetivo
    $targetQuery = $conn_mysql->prepare("SELECT * FROM usuarios WHERE id_user = ? AND status = 1");
    $targetQuery->bind_param('i', $target_user_id);
    $targetQuery->execute();
    $targetUser = $targetQuery->get_result()->fetch_assoc();
    
    if (!$targetUser) {
        return ['success' => false, 'message' => 'Usuario no encontrado o inactivo'];
    }
    
    // Guardar la sesión original del administrador
    $_SESSION['original_admin'] = [
        'id_user' => $_SESSION['id_cliente'],
        'username' => $_SESSION['username'],
        'TipoUserSession' => $_SESSION['TipoUserSession']
    ];
    
    // Actualizar la sesión con los datos del usuario objetivo
    $_SESSION['id_cliente'] = $targetUser['id_user'];
    $_SESSION['username'] = $targetUser['usuario'];
    $_SESSION['TipoUserSession'] = $targetUser['tipo'];
    
    // Registrar la actividad
    $admin_username = $_SESSION['original_admin']['username'];
    logActivity('SUDO_LOGIN', "Admin $admin_username inició sesión como usuario: " . $targetUser['usuario']);
    
    return ['success' => true, 'message' => 'Sesión iniciada como ' . $targetUser['nombre']];
}

// ============================================================================
// FUNCIÓN PARA REGRESAR A LA SESIÓN ORIGINAL
// ============================================================================
function sudoLogout() {
    if (!isset($_SESSION['original_admin'])) {
        return ['success' => false, 'message' => 'No hay sesión sudo activa'];
    }
    
    $original_admin = $_SESSION['original_admin'];
    $current_username = $_SESSION['username'];
    
    // Restaurar sesión original
    $_SESSION['id_cliente'] = $original_admin['id_user'];
    $_SESSION['username'] = $original_admin['username'];
    $_SESSION['TipoUserSession'] = $original_admin['TipoUserSession'];
    
    // Limpiar datos de sudo
    unset($_SESSION['original_admin']);
    
    // Registrar la actividad
    logActivity('SUDO_LOGOUT', "Admin $original_admin[username] regresó a su sesión desde: $current_username");
    
    return ['success' => true, 'message' => 'Sesión restaurada'];
}

// ============================================================================
// FUNCIÓN PARA VERIFICAR SI ES UNA SESIÓN SUDO
// ============================================================================
function isSudoSession() {
    return isset($_SESSION['original_admin']);
}        
// ============================================================================
// CONTRASEÑA GENÉRICA - DETECCIÓN Y SEGURIDAD
// ============================================================================
define('GENERIC_PASSWORD', '12345');
define('GENERIC_PASSWORD_MD5', '827ccb0eea8a706c4c34a16891f84e7b');

// Función para verificar si el usuario tiene contraseña genérica
function hasGenericPassword($user_id) {
    global $conn_mysql;
    
    $query = $conn_mysql->prepare("SELECT pass FROM usuarios WHERE id_user = ?");
    $query->bind_param('i', $user_id);
    $query->execute();
    $result = $query->get_result();
    
    if ($result && $row = $result->fetch_assoc()) {
        return $row['pass'] === GENERIC_PASSWORD_MD5;
    }
    
    return false;
}

// Función para cambiar la contraseña
function changePassword($user_id, $new_password) {
    global $conn_mysql;
    
    $hashed_password = md5($new_password);
    $query = $conn_mysql->prepare("UPDATE usuarios SET pass = ? WHERE id_user = ?");
    $query->bind_param('si', $hashed_password, $user_id);
    
    if ($query->execute()) {
        // Registrar el cambio de contraseña
        logActivity('PASSWORD_CHANGE', 'Usuario cambió su contraseña genérica');
        return true;
    }
    
    return false;
}
?>
