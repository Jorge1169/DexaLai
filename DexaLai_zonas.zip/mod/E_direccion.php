<?php
// E_direccion.php - Editar Bodega de Cliente

// Obtener ID de la dirección
$id_direccion = clear($_GET['id'] ?? '');

// Obtener datos de la bodega
$direccion = [];
$cliente = [];

if ($id_direccion) {
    // Obtener datos de la bodega
    $sqlDireccion = "SELECT * FROM direcciones WHERE id_direc = ?";
    $stmtDireccion = $conn_mysql->prepare($sqlDireccion);
    $stmtDireccion->bind_param('i', $id_direccion);
    $stmtDireccion->execute();
    $resultDireccion = $stmtDireccion->get_result();
    $direccion = $resultDireccion->fetch_assoc();
    
    // Obtener datos del cliente asociado
    if (!empty($direccion['id_us'])) {
        $sqlCliente = "SELECT id_cli, cod, nombre, rs FROM clientes WHERE id_cli = ?";
        $stmtCliente = $conn_mysql->prepare($sqlCliente);
        $stmtCliente->bind_param('i', $direccion['id_us']);
        $stmtCliente->execute();
        $resultCliente = $stmtCliente->get_result();
        $cliente = $resultCliente->fetch_assoc();
    }
}

if (isset($_POST['guardarDireccion'])) {
    try {
        $DireccionData = [
            'cod_al' => $_POST['cod_al'] ?? '',
            'noma' => $_POST['noma'] ?? '',
            'atencion' => $_POST['atencion'] ?? '',
            'tel' => $_POST['tel'] ?? '',
            'email' => $_POST['email'] ?? '',
            'obs' => $_POST['obs'] ?? '',
            'id_direc' => $id_direccion
        ];

        // Actualizar bodega
        $setParts = [];
        $types = '';
        $values = [];
        
        foreach ($DireccionData as $key => $value) {
            if ($key !== 'id_direc') {
                $setParts[] = "$key = ?";
                $types .= 's';
                $values[] = $value;
            }
        }
        
        $values[] = $id_direccion; // Para el WHERE
        
        $sql = "UPDATE direcciones SET " . implode(', ', $setParts) . " WHERE id_direc = ?";
        $stmt = $conn_mysql->prepare($sql);
        $stmt->bind_param($types . 'i', ...$values);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            alert("Bodega actualizada exitosamente", 1, "V_cliente&id=" . $cliente['id_cli']);

            logActivity('EDITAR', 'Edito la bodega ' . $id_direccion . ' Para el cliente '. $cliente['id_cli']);

        } else {
            alert("No se realizaron cambios en la bodega", 1, "V_cliente&id=" . $cliente['id_cli']);
            logActivity('EDITAR', 'No realizo cambios en la bodega ' . $id_direccion . ' Para el cliente '. $cliente['id_cli']);
        }
    } catch (mysqli_sql_exception $e) {
        alert("Error: " . $e->getMessage(), 0, "E_direccion&id=$id_direccion");
        logActivity('EDITAR', 'Error al tratar de editar la bodega ' . $id_direccion . ' Para el cliente '. $cliente['id_cli']);
    }
}
?>

<div class="container mt-2">
    <div class="card shadow-sm">
        <div class="card-header encabezado-col text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Editar Bodega</h5>
            <a href="?p=V_cliente&id=<?= $cliente['id_cli'] ?? '' ?>" class="btn btn-sm btn-secondary">
                <i class="bi bi-arrow-left"></i> Regresar
            </a>
        </div>
        <div class="card-body">
            <!-- Información del cliente -->
            <div class="mb-4 p-3 border rounded">
                <h6>Cliente asociado:</h6>
                <div class="row">
                    <div class="col-md-4">
                        <p class="mb-1"><strong>Código:</strong> <?= htmlspecialchars($cliente['cod'] ?? '') ?></p>
                    </div>
                    <div class="col-md-4">
                        <p class="mb-1"><strong>Nombre:</strong> <?= htmlspecialchars($cliente['nombre'] ?? '') ?></p>
                    </div>
                    <div class="col-md-4">
                        <p class="mb-1"><strong>Razón Social:</strong> <?= htmlspecialchars($cliente['rs'] ?? '') ?></p>
                    </div>
                </div>
            </div>
            
            <form class="forms-sample" method="post" action="">
                <!-- Campos de la bodega -->
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="cod_al" class="form-label">Código de Bodega</label>
                        <input name="cod_al" type="text" class="form-control" id="cod_al" 
                               value="<?= htmlspecialchars($direccion['cod_al'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="noma" class="form-label">Nombre de Bodega</label>
                        <input name="noma" type="text" class="form-control" id="noma" 
                               value="<?= htmlspecialchars($direccion['noma'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="atencion" class="form-label">Atención</label>
                        <input name="atencion" type="text" class="form-control" id="atencion" 
                               value="<?= htmlspecialchars($direccion['atencion'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="tel" class="form-label">Teléfono</label>
                        <input name="tel" type="tel" class="form-control" id="tel" 
                               value="<?= htmlspecialchars($direccion['tel'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="email" class="form-label">Email</label>
                        <input name="email" type="email" class="form-control" id="email" 
                               value="<?= htmlspecialchars($direccion['email'] ?? '') ?>">
                    </div>
                    <div class="col-12">
                        <label for="obs" class="form-label">Observaciones</label>
                        <textarea name="obs" class="form-control" id="obs" rows="3"><?= htmlspecialchars($direccion['obs'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- Botones de acción -->
                <div class="d-flex justify-content-md-end mt-4">
                    <button type="submit" name="guardarDireccion" class="btn btn-primary">
                        <i class="bi bi-save"></i> Guardar Cambios
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal de confirmación para desactivar bodega -->
<div class="modal fade" id="confirmDesactivarModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar desactivación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que deseas desactivar esta bodega?</p>
                <input type="hidden" id="direccionDesactivarId">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmDesactivarBtn">Desactivar</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Configurar modal para desactivar bodega
    $(document).on('click', '.desactivar-direccion-btn', function() {
        const id = $(this).data('id');
        $('#direccionDesactivarId').val(id);
        $('#confirmDesactivarModal').modal('show');
    });
    
    // Confirmar desactivación
    $('#confirmDesactivarBtn').click(function() {
        const id = $('#direccionDesactivarId').val();
        
        $.post('mod/desactivar_direccion.php', {
            id: id
        }, function(response) {
            if (response.success) {
                window.location.href = 'V_cliente&id=<?= $cliente['id_cli'] ?? '' ?>';
            } else {
                alert('Error: ' + response.message);
            }
        }, 'json').fail(function(jqXHR, textStatus, errorThrown) {
            alert('Error en la solicitud: ' + textStatus + ', ' + errorThrown);
        });
        
        $('#confirmDesactivarModal').modal('hide');
    });
});
</script>