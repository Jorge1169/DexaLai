<?php
// config/groq_key.php
define('GROQ_API_KEY', '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');
?>
